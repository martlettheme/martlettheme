# martlet agent tools

Experimental MIT local stdio MCP and companion builder skill. Source https://github.com/howardjp/design-workbench/tree/4e8509c60eef5e8b36984e6164984152bb4f33c2; content digest 4da1a604c6fc610f6af39011395f6bdf9a39157731ba53d6d0c8ebd3cf1c6eee.

Run npm install --ignore-scripts in this directory, then configure a stdio MCP client with command node and args ["/absolute/path/to/index.mjs"]. The client starts the process. The server exposes get_manifest, search_guidance, get_reference, and exact resources. Confirm the family using get_manifest.

Copy martlet-builder into your client's supported skills directory. Hosted setup and actual package availability are recorded by get_manifest; no static-audit or production-accessibility certification is claimed. This archive includes no workbench server or database.
