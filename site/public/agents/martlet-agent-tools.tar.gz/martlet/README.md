# martlet agent tools

Experimental MIT local stdio MCP and companion builder skill. Source https://github.com/howardjp/design-workbench/tree/95b10df8cd984754e1ed3e6034e29040ea908d0e; content digest 57928dfcb46c6392f403e42df26279262cf553cc423bf37a0e24edb72dce1d84.

Run npm install --ignore-scripts in this directory, then configure a stdio MCP client with command node and args ["/absolute/path/to/index.mjs"]. The client starts the process. The server exposes get_manifest, search_guidance, get_reference, and exact resources. Confirm the family using get_manifest.

Copy martlet-builder into your client's supported skills directory. Hosted setup and actual package availability are recorded by get_manifest; no static-audit or production-accessibility certification is claimed. This archive includes no workbench server or database.
