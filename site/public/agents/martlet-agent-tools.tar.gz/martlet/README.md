# martlet agent tools

Experimental MIT local stdio MCP and companion builder skill. Source https://github.com/k3jph/design-workbench/tree/39d664082bb0dbdb09bc182a6abffebef75518ff; content digest 1e22377c734c58cbdb9c3644fc8a156fe8d70d474783dd1c5212bce9fe3ada60.

Run npm install --ignore-scripts in this directory, then configure a stdio MCP client with command node and args ["/absolute/path/to/index.mjs"]. The client starts the process. The server exposes get_manifest, search_guidance, get_reference, and exact resources. Confirm the family using get_manifest.

Copy martlet-builder into your client's supported skills directory. Hosted setup and actual package availability are recorded by get_manifest; no static-audit or production-accessibility certification is claimed. This archive includes no workbench server or database.
