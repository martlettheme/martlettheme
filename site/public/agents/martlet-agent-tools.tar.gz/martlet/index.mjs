import { run } from './server.mjs';
await run('martlet',new URL('./catalog.json',import.meta.url));
